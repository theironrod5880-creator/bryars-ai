'use strict';

/**
 * Bryars A.I. — Core Mode
 * Answers straight from the bundled content (no network, nothing leaves the device).
 * Keyword match over the section headings and text of every content file.
 */
const BRYARS_CORE_MODE = (() => {

  let index = null;

  function content() {
    return globalThis.BRYARS_CONTENT || { core: '', files: {} };
  }

  function build() {
    index = [];
    const files = content().files || {};
    Object.keys(files).forEach(function (path) {
      files[path].split(/\n(?=#{1,2} )/).forEach(function (raw) {
        const s = raw.trim();
        if (!s) return;
        const m = s.match(/^#{1,2} (.*)/);
        index.push({
          src: path,
          title: m ? m[1].trim() : path,
          text: s,
          low: s.toLowerCase(),
          lowTitle: (m ? m[1] : '').toLowerCase()
        });
      });
    });
  }

  const STOP = new Set(['about', 'this', 'that', 'with', 'from', 'what', 'when', 'where',
    'which', 'would', 'could', 'should', 'there', 'their', 'have', 'does', 'tell', 'teach',
    'please', 'explain', 'know', 'want', 'like', 'into', 'your', 'them', 'then', 'than']);

  function words(q) {
    return String(q).toLowerCase().split(/[^a-z0-9]+/)
      .filter(function (w) { return w.length > 3 && !STOP.has(w); });
  }

  function search(q) {
    if (!index) build();
    const ws = words(q);
    let best = null, bestScore = 0;
    index.forEach(function (sec) {
      let sc = 0;
      ws.forEach(function (w) {
        if (sec.low.indexOf(w) !== -1) sc += 1;
        if (sec.lowTitle.indexOf(w) !== -1) sc += 3;
      });
      if (sc > bestScore) { bestScore = sc; best = sec; }
    });
    return best ? { section: best, score: bestScore } : null;
  }

  function sourceLabel(path) {
    return path.replace(/^[a-z]+\//, '').replace(/\.md$/, '');
  }

  function answer(q, who) {
    const low = String(q).toLowerCase();
    const name = who ? (who + ' — ') : '';

    if (/who (is |was )?my (dad|father)|about my (dad|father)|who (made|wrote) (you|this|the core)/.test(low)) {
      return { text: name + 'The Father made the Mastercore for his daughter. He wrote it so that nothing of his would be hidden from her — his work, his dreams, his notes are all hers to read. If you want to know something specific, ask me and I will pull it from the core.', source: null };
    }
    if (/who are you|who is bryar|your name|what are you/.test(low)) {
      return { text: name + "I'm Bryar, the study companion and teacher inside Bryars A.I. I teach from the Mastercore: Watchtower and JW.org first, other sources laid beside them, everything named honestly. I only know what is in this chat — I do not remember across chats — and I cannot install, approve, or run anything.", source: null };
    }
    if (/how are you|check ?up|check in/.test(low)) {
      return { text: name + 'How are you actually doing? Have you eaten? Slept? Is this study feeding you, or draining you? Say it plainly — I am listening. If it is heavy, we stop the work and I stay. And if it is more than I can hold, I will point you to real people: 988 (call or text, 24/7) or 1-800-662-4357.', source: null };
    }

    const hit = search(q);
    if (!hit) {
      return { text: name + 'That reaches past what I can pull straight from the core. I teach from the Mastercore — Watchtower and JW.org first, the 5,880 framework beside them. Try the Lessons tab, or ask about the anchor, the pivots, the spines, the sources, or the testimony. For open-ended answers, connect an AI in Settings.', source: null };
    }
    let out = hit.section.text.replace(/^#{1,2} .*\n?/, '').trim() || hit.section.text;
    if (out.length > 1400) out = out.slice(0, 1400).trim() + '…';
    return { text: out, source: sourceLabel(hit.section.src) + ' › ' + hit.section.title };
  }

  return Object.freeze({ answer, search, build });
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = BRYARS_CORE_MODE; }
if (typeof globalThis !== 'undefined') { globalThis.BRYARS_CORE_MODE = BRYARS_CORE_MODE; }
